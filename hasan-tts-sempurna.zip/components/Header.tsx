import React from 'react';
import { MusicalNoteIcon } from '@heroicons/react/24/solid';

export const Header: React.FC = () => {
  return (
    <header className="bg-sky-50/80 backdrop-blur-md border-b border-sky-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-sky-600 p-2 rounded-lg shadow-lg shadow-sky-500/20">
            <MusicalNoteIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Hasan <span className="text-sky-600">TTS</span> Studio
            </h1>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">
              Edisi 100+ Suara
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
             <a 
              href="#" 
              className="hidden md:block text-sm font-medium text-slate-500 hover:text-sky-600 transition-colors"
             >
               Dokumentasi
             </a>
             <div className="h-8 w-[1px] bg-sky-200 hidden md:block"></div>
             <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-sky-200">
                <div className="w-2 h-2 rounded-full bg-sky-500 animate-pulse"></div>
                <span className="text-xs text-slate-500 font-mono">API Terhubung</span>
             </div>
        </div>
      </div>
    </header>
  );
};