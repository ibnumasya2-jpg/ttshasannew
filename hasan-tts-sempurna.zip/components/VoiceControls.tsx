import React from 'react';
import { VoiceSettings } from '../types';
import { AdjustmentsHorizontalIcon, SpeakerWaveIcon, MusicalNoteIcon, ClockIcon } from '@heroicons/react/24/solid';

interface VoiceControlsProps {
  settings: VoiceSettings;
  onChange: (settings: VoiceSettings) => void;
  disabled?: boolean;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({ settings, onChange, disabled }) => {
  
  const handleChange = (key: keyof VoiceSettings, value: number) => {
    onChange({
      ...settings,
      [key]: value
    });
  };

  return (
    <div className="space-y-6">
       {/* Speaking Rate */}
       <div className="space-y-2">
          <div className="flex justify-between text-sm text-slate-600">
            <div className="flex items-center gap-2">
                <ClockIcon className="w-4 h-4 text-sky-500" />
                <label htmlFor="rate-slider">Kecepatan Bicara</label>
            </div>
            <span className="font-mono text-sky-600">{settings.speakingRate.toFixed(1)}x</span>
          </div>
          <input
            id="rate-slider"
            type="range"
            min="0.5"
            max="2.0"
            step="0.1"
            value={settings.speakingRate}
            onChange={(e) => handleChange('speakingRate', parseFloat(e.target.value))}
            disabled={disabled}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>0.5x</span>
            <span>Normal</span>
            <span>2.0x</span>
          </div>
       </div>

       {/* Pitch */}
       <div className="space-y-2">
          <div className="flex justify-between text-sm text-slate-600">
            <div className="flex items-center gap-2">
                <MusicalNoteIcon className="w-4 h-4 text-sky-500" />
                <label htmlFor="pitch-slider">Nada (Pitch)</label>
            </div>
            <span className="font-mono text-sky-600">
                {settings.pitch > 0 ? '+' : ''}{settings.pitch}
            </span>
          </div>
          <input
            id="pitch-slider"
            type="range"
            min="-10"
            max="10"
            step="1"
            value={settings.pitch}
            onChange={(e) => handleChange('pitch', parseInt(e.target.value))}
            disabled={disabled}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
           <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>Rendah (-10)</span>
            <span>Normal</span>
            <span>Tinggi (+10)</span>
          </div>
       </div>

       {/* Volume */}
       <div className="space-y-2">
          <div className="flex justify-between text-sm text-slate-600">
             <div className="flex items-center gap-2">
                <SpeakerWaveIcon className="w-4 h-4 text-sky-500" />
                <label htmlFor="volume-slider">Volume</label>
             </div>
            <span className="font-mono text-sky-600">{Math.round(settings.volume * 100)}%</span>
          </div>
          <input
            id="volume-slider"
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={settings.volume}
            onChange={(e) => handleChange('volume', parseFloat(e.target.value))}
            disabled={disabled}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
       </div>
    </div>
  );
};