import React from 'react';

interface TextInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  placeholder?: string;
}

export const TextInput: React.FC<TextInputProps> = ({ value, onChange, disabled, placeholder }) => {
  return (
    <textarea
      className="
        w-full flex-grow bg-slate-50 text-slate-900 border border-slate-200 rounded-xl p-4 
        focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent
        placeholder:text-slate-400 resize-none font-light leading-relaxed tracking-wide
        disabled:opacity-50 disabled:cursor-not-allowed transition-all
      "
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      maxLength={10000}
    />
  );
};