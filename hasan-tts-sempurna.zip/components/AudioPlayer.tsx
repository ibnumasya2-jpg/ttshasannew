import React, { useEffect, useRef, useState } from 'react';
import { PlayIcon, PauseIcon } from '@heroicons/react/24/solid';

interface AudioPlayerProps {
  audioUrl: string;
  volume: number;       // 0.0 to 1.0
  playbackRate: number; // 0.5 to 2.0
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ audioUrl, volume, playbackRate }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  // Sync volume and rate whenever they change
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.playbackRate = playbackRate;
    }
  }, [volume, playbackRate]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateProgress = () => {
      setProgress((audio.currentTime / audio.duration) * 100);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
    };
    
    const handleLoadedMetadata = () => {
        if (audio.duration !== Infinity) {
            setDuration(audio.duration);
        }
    };
    
    // Sometimes duration is available immediately, sometimes on metadata load
    // Fix for Infinity duration issue with blobs sometimes
    if (audio.readyState >= 1) {
        setDuration(audio.duration);
    }

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const formatTime = (time: number) => {
      if (isNaN(time) || !isFinite(time)) return "0:00";
      const min = Math.floor(time / 60);
      const sec = Math.floor(time % 60);
      return `${min}:${sec < 10 ? '0' + sec : sec}`;
  }

  return (
    <div className="bg-slate-50 rounded-xl p-4 border border-sky-100 relative overflow-hidden">
      {/* Ambient Background Glow */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-sky-500/10 to-blue-500/10 pointer-events-none"></div>
      
      <audio ref={audioRef} src={audioUrl} className="hidden" />
      
      <div className="flex items-center gap-5 relative z-10">
        <button
          onClick={togglePlay}
          className="w-14 h-14 flex items-center justify-center rounded-full bg-gradient-to-br from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white transition-all shadow-lg shadow-sky-500/30 flex-shrink-0 transform active:scale-95"
        >
          {isPlaying ? (
            <PauseIcon className="w-7 h-7" />
          ) : (
            <PlayIcon className="w-7 h-7 pl-1" />
          )}
        </button>

        <div className="flex-grow space-y-3">
           {/* Visualizer Animation */}
           <div className="h-6 flex items-end gap-1 opacity-80 overflow-hidden mask-image-gradient">
                {Array.from({ length: 50 }).map((_, i) => (
                    <div 
                        key={i} 
                        className={`w-1 rounded-t-sm bg-gradient-to-t from-sky-500 to-blue-400 transition-all duration-150`}
                        style={{
                            height: isPlaying ? `${20 + Math.random() * 80}%` : '15%',
                            opacity: isPlaying ? 1 : 0.3
                        }}
                    ></div>
                ))}
           </div>

           {/* Progress Bar */}
           <div className="relative w-full h-2 bg-slate-200 rounded-full overflow-hidden group cursor-pointer" onClick={(e) => {
               if(!audioRef.current) return;
               const rect = e.currentTarget.getBoundingClientRect();
               const x = e.clientX - rect.left;
               const p = x / rect.width;
               audioRef.current.currentTime = p * audioRef.current.duration;
           }}>
             <div 
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-sky-400 to-blue-400 rounded-full shadow-[0_0_10px_rgba(56,189,248,0.5)] transition-all duration-100"
                style={{ width: `${progress}%` }}
             />
           </div>
           
           <div className="flex justify-between text-xs font-medium font-mono text-slate-500">
                <span>{formatTime(audioRef.current?.currentTime || 0)}</span>
                <span className="text-sky-600">{formatTime(duration)}</span>
           </div>
        </div>
      </div>
    </div>
  );
};