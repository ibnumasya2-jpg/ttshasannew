import React, { useState, useMemo } from 'react';
import { AVAILABLE_VOICES } from '../constants';
import { VoiceOption } from '../types';
import { MicrophoneIcon, ChevronDownIcon, ChevronUpIcon, CheckCircleIcon, MagnifyingGlassIcon, XMarkIcon } from '@heroicons/react/24/solid';

interface VoiceSelectorProps {
  selected: VoiceOption;
  onSelect: (voice: VoiceOption) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ selected, onSelect }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [openCategory, setOpenCategory] = useState<string | null>(selected.category);

  // Filter voices based on search query
  const { categories, filteredVoicesByCat } = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    
    let matches = AVAILABLE_VOICES;
    if (query) {
      matches = AVAILABLE_VOICES.filter(v => 
        v.name.toLowerCase().includes(query) || 
        v.category.toLowerCase().includes(query) ||
        v.description.toLowerCase().includes(query)
      );
    }

    // Get unique categories from matches
    const cats = Array.from(new Set(matches.map(v => v.category)));
    
    // Group matches by category
    const grouped: Record<string, VoiceOption[]> = {};
    cats.forEach(cat => {
      grouped[cat] = matches.filter(v => v.category === cat);
    });

    return { categories: cats, filteredVoicesByCat: grouped };
  }, [searchQuery]);

  // Auto-expand categories when searching
  useMemo(() => {
    if (searchQuery && categories.length > 0) {
      setOpenCategory(categories[0]);
    }
  }, [searchQuery, categories]);

  const toggleCategory = (category: string) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  const getGenderLabel = (gender: string) => {
    if (gender === 'Male') return 'Pria';
    if (gender === 'Female') return 'Wanita';
    return 'Netral';
  }

  return (
    <div className="flex flex-col h-full">
      {/* Sticky Search Bar Area */}
      <div className="sticky top-0 z-20 bg-white pb-2">
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <MagnifyingGlassIcon className="h-4 w-4 text-sky-400 group-focus-within:text-sky-500 transition-colors" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-10 py-2.5 border border-sky-200 rounded-xl leading-5 bg-sky-50/30 placeholder-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 sm:text-sm transition-all shadow-sm"
            placeholder="Cari suara (contoh: 'Wanita', 'Deep')..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-red-500 transition-colors"
            >
              <XMarkIcon className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Scrollable Voice List */}
      <div className="flex-grow overflow-y-auto pr-1 custom-scrollbar space-y-3 max-h-[300px] lg:max-h-[550px] pb-2">
        {categories.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-sm flex flex-col items-center gap-2">
            <MagnifyingGlassIcon className="w-8 h-8 text-slate-200" />
            <p>Tidak ada suara yang cocok.</p>
          </div>
        ) : (
          categories.map(category => {
            const isOpen = openCategory === category || searchQuery.length > 0;
            const voicesInCategory = filteredVoicesByCat[category] || [];
            const isActiveCategory = selected.category === category;
            const hasActiveVoice = voicesInCategory.some(v => v.id === selected.id);

            return (
              <div 
                key={category} 
                className={`
                  border rounded-xl overflow-hidden transition-all duration-200
                  ${hasActiveVoice ? 'border-sky-300 shadow-sm ring-1 ring-sky-100' : 'border-sky-100 hover:border-sky-200'}
                  bg-white
                `}
              >
                <button
                  onClick={() => toggleCategory(category)}
                  className={`
                    w-full flex items-center justify-between p-3 text-left transition-colors relative overflow-hidden
                    ${isOpen ? 'bg-sky-50/80 text-sky-900' : 'bg-white text-slate-700 hover:bg-sky-50/50'}
                  `}
                >
                  <div className="flex items-center gap-2.5 relative z-10">
                    {hasActiveVoice ? (
                       <div className="p-1 bg-sky-100 rounded-full">
                         <MicrophoneIcon className="w-3.5 h-3.5 text-sky-600" />
                       </div>
                    ) : (
                       <div className="w-6 h-6 flex items-center justify-center rounded-full bg-slate-100 text-slate-400">
                          <span className="text-[10px] font-bold">{voicesInCategory.length}</span>
                       </div>
                    )}
                    <span className={`font-semibold text-sm ${hasActiveVoice ? 'text-sky-800' : ''}`}>
                      {category}
                    </span>
                  </div>
                  
                  {isOpen ? (
                    <ChevronUpIcon className="w-4 h-4 text-sky-400" />
                  ) : (
                    <ChevronDownIcon className="w-4 h-4 text-slate-300" />
                  )}
                </button>

                {isOpen && (
                  <div className="bg-white border-t border-sky-100">
                    {voicesInCategory.map(voice => {
                      const isSelected = selected.id === voice.id;
                      return (
                        <button
                          key={voice.id}
                          onClick={() => onSelect(voice)}
                          className={`
                            w-full text-left px-4 py-3 border-b border-slate-50 last:border-0 transition-all flex items-start gap-3 group relative
                            ${isSelected ? 'bg-sky-50/80' : 'hover:bg-slate-50'}
                          `}
                        >
                          {isSelected && (
                            <div className="absolute left-0 top-0 bottom-0 w-1 bg-sky-500" />
                          )}
                          
                          <div className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 transition-all ${isSelected ? 'bg-sky-500 shadow-[0_0_8px_rgba(56,189,248,0.8)] scale-110' : 'bg-slate-200 group-hover:bg-sky-300'}`} />
                          
                          <div className="flex-grow min-w-0">
                            <div className="flex justify-between items-center mb-0.5">
                              <span className={`text-sm font-medium truncate pr-2 ${isSelected ? 'text-sky-900' : 'text-slate-700'}`}>
                                {voice.name}
                              </span>
                              <span className={`text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded border flex-shrink-0 ${
                                isSelected 
                                  ? 'bg-sky-100 text-sky-700 border-sky-200' 
                                  : 'bg-slate-100 text-slate-500 border-slate-200'
                              }`}>
                                {getGenderLabel(voice.gender)}
                              </span>
                            </div>
                            <p className={`text-xs leading-relaxed line-clamp-2 ${isSelected ? 'text-sky-700/80' : 'text-slate-400'}`}>
                              {voice.description}
                            </p>
                          </div>
                          
                          {isSelected && <CheckCircleIcon className="w-5 h-5 text-sky-500 flex-shrink-0 self-center" />}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};