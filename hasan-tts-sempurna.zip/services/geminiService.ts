import { GoogleGenAI, Modality } from "@google/genai";

// Initialize the Gemini API client
// Note: API Key must be provided via environment variable
const apiKey = process.env.API_KEY;

export const generateSpeech = async (text: string, voiceName: string, pitch: number = 0): Promise<string> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey });

  // Gemini TTS (preview) can error (500) if systemInstruction is used in config.
  // Instead, we prepend style directives to the text prompt itself, similar to "Say cheerfully: ...".
  
  let stylePrefix = "";
  if (pitch !== 0) {
      if (pitch <= -8) stylePrefix = "Say with a very deep, bass-heavy voice: ";
      else if (pitch <= -4) stylePrefix = "Say with a deep, authoritative voice: ";
      else if (pitch < 0) stylePrefix = "Say with a slightly lower pitch: ";
      else if (pitch >= 8) stylePrefix = "Say with a very high-pitched, youthful voice: ";
      else if (pitch >= 4) stylePrefix = "Say with a high, bright voice: ";
      else if (pitch > 0) stylePrefix = "Say with a slightly higher pitch: ";
  }

  // Combine directive with text
  const finalPrompt = stylePrefix ? `${stylePrefix}${text}` : text;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [
        {
          parts: [
            { text: finalPrompt }
          ]
        }
      ],
      config: {
        // systemInstruction is removed to prevent 500 errors
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { 
                voiceName: voiceName 
            },
          },
        },
      },
    });

    // Extract the base64 audio data
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      throw new Error("No audio data received from the model.");
    }

    return base64Audio;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};