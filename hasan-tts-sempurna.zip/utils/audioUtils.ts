/**
 * Decodes a base64 string into a Uint8Array
 */
const base64ToUint8Array = (base64: string): Uint8Array => {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

declare global {
  interface Window {
    lamejs: any;
  }
}

/**
 * Encodes raw PCM data to MP3 using lamejs if available, otherwise falls back to WAV.
 * Assumes 24kHz, 1 channel (Mono), 16-bit samples as per typical Gemini TTS output.
 */
export const createMp3Blob = (base64Audio: string, sampleRate: number = 24000): Blob => {
  const pcmData = base64ToUint8Array(base64Audio);
  
  // Try MP3 encoding
  if (window.lamejs) {
    try {
      // Gemini returns 16-bit PCM. Convert bytes to Int16Array for lamejs.
      const samples = new Int16Array(pcmData.buffer);
      const lib = window.lamejs;
      // Initialize encoder: Mono (1 channel), sampleRate (24000), kbps (128)
      const mp3encoder = new lib.Mp3Encoder(1, sampleRate, 128);
      
      const mp3Data = [];
      
      const mp3buf = mp3encoder.encodeBuffer(samples);
      if (mp3buf.length > 0) {
        mp3Data.push(mp3buf);
      }
      
      const endBuf = mp3encoder.flush();
      if (endBuf.length > 0) {
        mp3Data.push(endBuf);
      }

      return new Blob(mp3Data, { type: 'audio/mp3' });
    } catch (e) {
      console.warn("MP3 encoding failed, falling back to WAV", e);
    }
  } else {
      console.warn("LameJS not found, falling back to WAV");
  }

  // Fallback to WAV
  return createSyncWavBlob(pcmData, sampleRate);
};

/**
 * Synchronous WAV creation for robust fallback
 */
const createSyncWavBlob = (pcmData: Uint8Array, sampleRate: number): Blob => {
  // WAV Header parameters
  const numChannels = 1;
  const byteRate = sampleRate * numChannels * 2; // 16-bit = 2 bytes
  const blockAlign = numChannels * 2;
  const wavHeaderSize = 44;
  const totalSize = wavHeaderSize + pcmData.length;
  
  const buffer = new ArrayBuffer(totalSize);
  const view = new DataView(buffer);
  
  // RIFF chunk descriptor
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + pcmData.length, true); // ChunkSize
  writeString(view, 8, 'WAVE');
  
  // fmt sub-chunk
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
  view.setUint16(22, numChannels, true); // NumChannels
  view.setUint32(24, sampleRate, true); // SampleRate
  view.setUint32(28, byteRate, true); // ByteRate
  view.setUint16(32, blockAlign, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample
  
  // data sub-chunk
  writeString(view, 36, 'data');
  view.setUint32(40, pcmData.length, true); // Subchunk2Size
  
  // Write PCM data
  const pcmBytes = new Uint8Array(buffer, 44);
  pcmBytes.set(pcmData);
  
  return new Blob([buffer], { type: 'audio/wav' });
}

const writeString = (view: DataView, offset: number, string: string) => {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
};